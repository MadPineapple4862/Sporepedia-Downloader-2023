#define CURL_STATICLIB
#include <iostream>
#include <curl/curl.h>
#pragma warning(disable:4996)
using namespace std;

static size_t responseToString(void* contents, size_t size, size_t nmemb, void* userp)
{
	((string*)userp)->append((char*)contents, size * nmemb);
	return size * nmemb;
}
static size_t writeData(void* ptr, size_t size, size_t nmemb, FILE* stream)
{
	size_t written = fwrite(ptr, size, nmemb, stream);
	return written;
}
void downloadCreation(char* id)
{
	char fileName[17] = "------------.png";
	for (int i = 0; i < 12; i++)
		fileName[i] = id[i];
	char url[63] = "http://www.spore.com/static/thumb/---/---/---/------------.png"; // Do not use https. It will not work.
	for (int i = 0; i < 3; i++)
		url[i + 34] = id[i];
	for (int i = 3; i < 6; i++)
		url[i + 35] = id[i];
	for (int i = 6; i < 9; i++)
		url[i + 36] = id[i];
	for (int i = 0; i < 12; i++)
		url[i + 46] = id[i];
	CURL* curl = curl_easy_init();
	FILE* file = fopen(fileName, "wb");
	curl_easy_setopt(curl, CURLOPT_URL, url);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeData);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, file);
	CURLcode response = curl_easy_perform(curl);
	curl_easy_cleanup(curl);
	fclose(file);
}
int main()
{
	string input;
	cout << "Enter 12-digit creation's ID: ";
	cin >> input;
	cout << "Please wait.";
	if (input.size() < 12)
		input = "------------";

	char url[63] = "http://www.spore.com/static/model/---/---/---/------------.xml"; // Do not use https. It will not work.
	for (int i = 0; i < 3; i++)
		url[i + 34] = input[i];
	for (int i = 3; i < 6; i++)
		url[i + 35] = input[i];
	for (int i = 6; i < 9; i++)
		url[i + 36] = input[i];
	for (int i = 0; i < 12; i++)
		url[i + 46] = input[i];

	CURL* curl;
	CURLcode cc_response;
	string response;
	curl = curl_easy_init();
	curl_easy_setopt(curl, CURLOPT_URL, url);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, responseToString);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
	cc_response = curl_easy_perform(curl);
	curl_easy_cleanup(curl);

	for (int i = 0; i < response.size(); i++)
	{
		if (response[i] == '<' &&
			response[i + 1] == 'a' &&
			response[i + 2] == 's' &&
			response[i + 3] == 's' &&
			response[i + 4] == 'e' &&
			response[i + 5] == 't' &&
			response[i + 6] == '>')
		{
			char fileName[12];
			for (int j = 0; j < 12; j++)
				fileName[j] = response[i + j + 7];
			downloadCreation(fileName);
		}
		else if ((((response[i] == '/' &&
			response[i + 7] == '>') ||
			(response[i] == '<' &&
				response[i + 7] == '/')) &&
			response[i + 1] == 'a' &&
			response[i + 2] == 's' &&
			response[i + 3] == 's' &&
			response[i + 4] == 'e' &&
			response[i + 5] == 't' &&
			response[i + 6] == 's') ||
			(response[i] == '<' &&
				response[i + 1] == 'b' &&
				response[i + 2] == 'l' &&
				response[i + 3] == 'o' &&
				response[i + 4] == 'c' &&
				response[i + 5] == 'k' &&
				response[i + 6] == 's'))
		{
			char fileName[12];
			for (int j = 0; j < 12; j++)
				fileName[j] = input[j];
			downloadCreation(fileName);
			break;
		}
	}

	return 0;
}

// Installing CURL by cmd (on Windows)
// 
// git clone https://github.com/Microsoft/vcpkg.git
// .\vcpkg\bootstrap-vcpkg.bat
// .\vcpkg install curl:x86-windows
// .\vcpkg install curl:x64-windows
// .\vcpkg integrate install
